//package co2103.hw2.domain;
//
//import java.util.ArrayList;
//
//import java.util.List;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToMany;
//
///**
// * 
// * @author jnaj1
// *This is the where the hotel attributes are represented
// */
//@Entity 
//public class Hotel {
//	/**
//	 * The Id is used to make all the hotels unique from one another 
//	 */
//	@Id
//	private String name;
//	private String description;
//	/**
//	 * Ensures that all the rooms are kept inn order and in track. 
//	 */
//    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
//    @JoinColumn
//	private List<Room> rooms = new ArrayList<>();
//    /**
//     * This gives the list of staff in the system 
//     */
//    @OneToMany
//    @JoinColumn
//    private List<Trainer> staff = new ArrayList<>();
//    /**
//     * This gives list of bookings in the system
//     */
//    @OneToMany(cascade= {CascadeType.MERGE}, mappedBy = "hotel")
//	
//	private List<Booking> bookings = new ArrayList<>();
//	
//	public Hotel() {
//	}
//
//	public Hotel(String name, String description) {
//		this.name = name;
//		this.description = description;
//	}
//
//	public List<Trainer> getStaff() {
//		return staff;
//	}
//
//	public void setStaff(List<Trainer> staff) {
//		this.staff = staff;
//	}
//
//	public List<Booking> getBookings() {
//		return bookings;
//	}
//
//	public void setBookings(List<Booking> bookings) {
//		this.bookings = bookings;
//	}
//
//	public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public String getDescription() {
//		return description;
//	}
//
//	public void setDescription(String description) {
//		this.description = description;
//	}
//
//	public List<Room> getRooms() {
//		return rooms;
//	}
//
//	public void setRooms(List<Room> rooms) {
//		this.rooms = rooms;
//	}
//
//}
