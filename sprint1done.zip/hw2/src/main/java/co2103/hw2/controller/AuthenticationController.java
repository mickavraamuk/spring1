package co2103.hw2.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import co2103.hw2.domain.Scheduler;
import co2103.hw2.domain.Trainer;
import co2103.hw2.domain.UserKind;
import co2103.hw2.domain.Users;
import co2103.hw2.repository.SchedulerRepository;
import co2103.hw2.repository.TrainerRepository;
import co2103.hw2.repository.UserRepository;

@Controller
public class AuthenticationController {
		@Autowired
		private UserRepository userrepo;
		
		@RequestMapping(value = "/login-form", method = RequestMethod.GET)
		public String loginForm() {
			return "security/login";
		}

		@RequestMapping(value = "/error-login", method = RequestMethod.GET)
		public String invalidLogin(Model model) {
			model.addAttribute("error", true);
			return "security/login";
		}

		/**
		 * Successful login is a redirect based on the role of the user
		 * 
		 * @param principal
		 * @return
		 */
		
		@RequestMapping(value = "/success-login", method = RequestMethod.GET)
		public String successLogin(Principal principal) {
			Users u = userrepo.findByUsername(principal.getName());
			if (u.getKind().equals(UserKind.Scheduler)) {
				return "redirect:/";
			}
			else
			return "redirect:/t/trainer";
		}

		@RequestMapping(value = "/access-denied", method = RequestMethod.GET)
		public String error() {
			return "security/denied";
		}
	}


