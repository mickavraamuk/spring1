//package co2103.hw2.domain;
//
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.Date;
//import java.util.List;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Entity;
//import javax.persistence.FetchType;
//import javax.persistence.GeneratedValue;
//import javax.persistence.Id;
//import javax.persistence.ManyToMany;
//import javax.persistence.ManyToOne;
//
//import org.springframework.format.annotation.DateTimeFormat;
///**
// * 
// * @author jnaj1
// *This public class contains the booking information for both hotels Ibis and Hilton.
// *There are many annotations in this class, one being the @Id, this is used to set ID to be he primary key. 
// *
// */
//
//@Entity
//public class Booking {
//	/**
//	 * The DateTimeFormat is used to create the format to make the bookings 
//	 * The ManyToManay annotation is used to allow many booking to apply to many guests
//	 * The ManyToOne annotation is used to carry out multiple bookings of the same guest.
//	 */
//	@Id
//	@GeneratedValue
//	/**
//	 * This is the Identificatioin which is unique to every hotel booking
//	 */
//	int id;
//	@DateTimeFormat(pattern = "yyyy-MM-dd")
//	/**
//	 * The date that the residence will be at the hotel 
//	 */
//	private Date start = Calendar.getInstance().getTime();
//	@DateTimeFormat(pattern = "yyyy-MM-dd")
//	/**
//	 * the date when the residence checkout from the hotel 
//	 */
//	private Date end = Calendar.getInstance().getTime();;
//	
//	@ManyToMany(cascade=CascadeType.MERGE)
//	/**
//	 * This is the list allows you to check the guests at the hotels.
//	 */
//    private List<Trainer> guests = new ArrayList<>();
//	
//	@ManyToOne(cascade=CascadeType.MERGE)
//	/**
//	 * 
//	 */
//
//	private Hotel hotel;
//
//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public List<Trainer> getGuests() {
//		return guests;
//	}
//
//	public void setGuests(List<Trainer> guests) {
//		this.guests = guests;
//	}
//
//	public Hotel getHotel() {
//		return hotel;
//	}
//
//	public void setHotel(Hotel hotel) {
//		this.hotel = hotel;
//	}
//
//	public Date getStart() {
//		return start;
//	}
//
//	public void setStart(Date start) {
//		this.start = start;
//	}
//
//	public Date getEnd() {
//		return end;
//	}
//
//	public void setEnd(Date end) {
//		this.end = end;
//	}
//	
//}
