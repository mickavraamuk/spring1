//package co2103.hw2.repository;
//
//import java.util.List;
//
//import org.springframework.data.repository.CrudRepository;
//
//import co2103.hw2.domain.Booking;
//
//public interface BookingRepository extends CrudRepository<Booking, Integer>{
//	public List<> findBynameContains(String name);
//}
