//package co2103.hw2.controller;
//
//import java.util.stream.Collectors;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//
//import co2103.hw2.Hw2Application;
//import co2103.hw2.domain.Booking;
//import co2103.hw2.domain.Hotel;
//
//
//@Controller
//@RequestMapping("/b/")
//public class BookingController {
//	
//	@GetMapping("/bookings")
//	public String showBookings(Model model) {
//		model.addAttribute("bookings", Hw2Application.bookings);
//		return "bookings/list";
//	}
//
//	@RequestMapping("/newBooking")
//	public String newBooking(Model model) {
//		model.addAttribute("hotels", Hw2Application.hotels.stream().map(x -> x.getName()).collect(Collectors.toList()));
//		model.addAttribute("booking", new Booking());
//		return "bookings/form";
//	}
//
//	@PostMapping("/addBooking")
//	public String addBooking(@ModelAttribute Booking booking, @RequestParam String hotelName) {
//		for (Hotel h : Hw2Application.hotels) {
//			if (hotelName.equals(h.getName())) {
//				booking.setHotel(h);
//				break;
//			}
//		}
//		booking.getGuests().add(Hw2Application.user);
//		Hw2Application.bookings.add(booking);		
//		booking.setId((int) System.currentTimeMillis());
//		return "redirect:/b/bookings";
//	}
//	
//	@GetMapping("/deleteBooking")
//	public String deleteBooking(@RequestParam int id) {
//		
//		for (Booking b : Hw2Application.bookings) {
//			if (b.getId() == id) {
//				Hw2Application.bookings.remove(b);
//				break;
//			}
//		}
//		return "redirect:/b/bookings";
//	}
//}
