package co2103.hw2.repository;

import org.springframework.data.repository.CrudRepository;
import co2103.hw2.domain.Trainer;

public interface TrainerRepository extends CrudRepository<Trainer, Integer> {
	public Trainer findByUsername (String username);
	public Trainer findById (int id);
}
