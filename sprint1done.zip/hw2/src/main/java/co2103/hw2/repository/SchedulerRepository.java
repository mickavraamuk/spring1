package co2103.hw2.repository;

import org.springframework.data.repository.CrudRepository;

import co2103.hw2.domain.Scheduler;

public interface SchedulerRepository extends CrudRepository<Scheduler, String> {
	public Scheduler findByUsername(String username);
}
