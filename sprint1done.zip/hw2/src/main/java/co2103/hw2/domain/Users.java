package co2103.hw2.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@Entity
public abstract class Users {
	/**
     * This Id for trainer creates a primary. It is specific to each one. 
     */
	@Id
	protected int id;
	/**
	 * This will include a trainer's username.
	 */
	protected String username;
	/**
	 * This variable would be used by trainer's when logging in to the system.
	 */
	protected String password;
	/**
	 * This will include the first and last name.
	 */
	protected String fullname;

	/**
	 * this variable is used for different types of users such as managers, guests and staff
	 */
	 protected UserKind kind;
	
	/**
	 * This will include a trainer's operating location.
	 */
	protected String operatinglocation;
	/**
	 * This will include a trainer's region.
	 */
	protected String region;
	/**
	 * This will include a trainer's skills.
	 */
	protected String skills;
	/**
	 * This will include a trainer's experience.
	 */
	protected String experience;
	
	public Users (int id,String fullName, String username, String password, String OperatingLocation, String Region, String skills, String experience, UserKind kind) {
		this.id = id;
		this.username = username;
		this.password = password;
		this.fullname = fullName;
		this.kind = kind;
		this.operatinglocation = OperatingLocation;
		this.region = Region;
		this.skills = skills;
		this.experience = experience;
	}
	
	public Users (int id,String fullName, String username, String password, String OperatingLocation, UserKind kind) {
		this.id = id;
		this.username = username;
		this.password = password;
		this.fullname = fullName;
		this.kind = kind;
		this.operatinglocation = OperatingLocation;

	}
	
	public Users() {
		
	}

	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
		
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getFullname() {
		return fullname;
	}
	
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	
	public UserKind getKind() {
		return kind;
	}
	
	public void setKind(UserKind kind) {
		this.kind = kind;
	}
	
	public String getOperatinglocation() {
		return operatinglocation;
	}
	
	public void setOperatinglocation(String operatinglocation) {
		this.operatinglocation = operatinglocation;
	}
	
	public String getRegion() {
		return region;
	}
	
	public void setRegion(String region) {
		this.region = region;
	}
	
	public String getSkills() {
		return skills;
	}
	
	public void setSkills(String skills) {
		this.skills = skills;
	}
	
	public String getExperience() {
		return experience;
	}
	
	public void setExperience(String experience) {
		this.experience = experience;
	}
}
