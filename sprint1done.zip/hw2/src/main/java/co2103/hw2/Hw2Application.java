
package co2103.hw2;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.password.PasswordEncoder;

import co2103.hw2.domain.Scheduler;
import co2103.hw2.domain.Trainer;
import co2103.hw2.domain.UserKind;
import co2103.hw2.repository.TrainerRepository;
import co2103.hw2.repository.SchedulerRepository;
import co2103.hw2.repository.UserRepository;
import co2103.hw2.domain.Users;

@SpringBootApplication
public class Hw2Application implements ApplicationRunner {

	@Autowired
	private UserRepository userrep;
	
	@Autowired
	private TrainerRepository trainerrep;
	@Autowired
	private PasswordEncoder passEnc;
	

	public static void main(String[] args) {
		SpringApplication.run(Hw2Application.class, args);
	}
	
	@Override
	public void run(ApplicationArguments args) throws Exception {
		
		List<Users> users = new ArrayList<Users>();
		List<Trainer> trainers= new ArrayList<Trainer>();		
		
		Trainer t1 = new Trainer (1, "fullname1", "username1", passEnc.encode("password"), "OperatingLocation1", "Region1", "Computer Hardware, Computer Software Knowledge, Internet Applications, Networks, Operating Systems" ,"Office Assistant with 6+ years of experience handling confidential tasks and making routine office tasks as efficient as possible. Proven managerial experience and cost-cutting abilities, while maintaining high standards and achieving company goals.", UserKind.Trainer);
		
		Trainer t3 = new Trainer (3, "Michael", "username3", passEnc.encode("password"), "OperatingLocation1", "Region1", "Skills1", "experience1", UserKind.Trainer);
		
		Scheduler s1 = new Scheduler (2, "fullname2", "username2", passEnc.encode("password"), "OperatingLocation2", UserKind.Scheduler);
		
		trainers.add(t1);
		trainers.add(t3);
		
		users.add(t1);
		users.add(s1);
		users.add(t3);
		
	userrep.saveAll(users);
	
		
		
		trainerrep.saveAll(trainers);
	}
}