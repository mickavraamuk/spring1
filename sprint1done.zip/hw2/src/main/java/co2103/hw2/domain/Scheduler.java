package co2103.hw2.domain;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
/**
 * 
 * @author jnaj1
 *This is the where the scheduler's attributes are represented. The username, fullname are all part of the person. 
 */
public class Scheduler extends Users {
//    /**
//     * This Id for trainer creates a primary. It is specific to each one. 
//     */
//	@Id
//	private int id;
//	/**
//	 * This will include a trainer's username.
//	 */
//	private String username;
//	/**
//	 * This variable would be used by trainer's when logging in to the system.
//	 */
//	private String password;
//	/**
//	 * This will include the first and last name.
//	 */
//	private String fullname;
//
//	/**
//	 * this variable is used for different types of users such as managers, guests and staff
//	 */
//	 	private UserKind kind;
//	/**
//	 * This will include a trainer's operating location.
//	 */
//	private String operatinglocation;

	public Scheduler() {
		
	}
	
	public Scheduler(int id,String fullname, String username, String password, String operatinglocation, UserKind kind) {
		this.id = id;
		this.username = username;
		this.password = password;
		this.fullname = fullname;
		this.kind = kind;
		this.operatinglocation = operatinglocation;
		}

//	public UserKind getKind() {
//		return kind;
//	}
//
//	public void setKind(UserKind kind) {
//		this.kind = kind;
//	}
//	public int getid() {
//		return id;
//	}
//	
//	public void setid(int id) {
//		this.id = id;
//	}
//	
//	public String getusername() {
//		return username;
//	}
//
//	public void setusername(String username) {
//		this.username = username;
//	}
//
//	public String getpassword() {
//		return password;
//	}
//
//	public void setpassword(String password) {
//		this.password = password;
//	}
//
//	public String getfullname() {
//		return fullName;
//	}
//
//	public void setfullname(String fullName) {
//		this.fullName = fullName;
//	}
//
//	public String getoperatinglocation() {
//		return OperatingLocation;
//	}
//
//	public void setoperatinglocation(String operatingLocation) {
//		OperatingLocation = operatingLocation;
//	}
}