package co2103.hw2.domain;

import javax.persistence.*;

@Entity
public class Person {
	@Id
	private String username;
	private String fullName;
	private String password;
	private UserKind kind;

	public Person() {
		super();
	}

	public Person(String fullName, String username, String password, UserKind kind) {
		this.fullName = fullName;
		this.kind = kind;
		this.username = username;
		this.password = password;
	}

	public UserKind getKind() {
		return kind;
	}

	public void setKind(UserKind kind) {
		this.kind = kind;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	@Override
	public String toString() {	
		return fullName;
	}
}
