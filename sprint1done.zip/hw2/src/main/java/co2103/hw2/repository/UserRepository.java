package co2103.hw2.repository;

import org.springframework.data.repository.CrudRepository;

import co2103.hw2.domain.Users;


public interface UserRepository extends CrudRepository<Users, String> {
	public Users findByUsername(String username);
}
