package co2103.hw2.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import co2103.hw2.Hw2Application;
import co2103.hw2.repository.SchedulerRepository;
import co2103.hw2.repository.UserRepository;

@Controller
public class MainController {
	
	@Autowired
	private SchedulerRepository schedulerrepo;
	
	@RequestMapping("/")
	public String starts(Model model, Principal principal) {
		model.addAttribute("scheduler", schedulerrepo.findByUsername(principal.getName()));
		return "start";
	}
}