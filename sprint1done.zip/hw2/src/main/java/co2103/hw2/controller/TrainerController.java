package co2103.hw2.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import co2103.hw2.domain.Trainer;
import co2103.hw2.domain.UserKind;
import co2103.hw2.domain.Users;
import co2103.hw2.repository.TrainerRepository;
import co2103.hw2.repository.UserRepository;

@Controller
@RequestMapping("/t/")
public class TrainerController {

	@Autowired
	private UserRepository userrepo;
	@Autowired
	private TrainerRepository trainerrepo;
	
	List<Users> listt = new ArrayList<Users>();

	@GetMapping("/trainer")
	public String start(Model model, Principal principal) {
		model.addAttribute("trainer", userrepo.findByUsername(principal.getName()));
		return "trainer/starttrainer";
	}
	
	/**
	 * @param model: This allows you to transfer data from wherever it is being used to the JSP
	 * @param principal:This will be used to return the list of bookings for the required user 
	 * @return: This is for the bookings and list and it shows the user the updated bookings list.
	 */
	@GetMapping(value = "/editprofile/{id}/{kind}")
	public String edittrainerprof(@PathVariable("id") int id, @PathVariable("kind") UserKind kind, Model model) {
		Trainer t1 = trainerrepo.findById(id);
		model.addAttribute("username", t1.getUsername());
		model.addAttribute("fullname", t1.getFullname());
		model.addAttribute("password", t1.getPassword());
		model.addAttribute("region", t1.getRegion());
		model.addAttribute("ol", t1.getOperatinglocation());
		model.addAttribute("skills", t1.getSkills());
		model.addAttribute("exp", t1.getExperience());
		model.addAttribute("id", t1.getId());
		model.addAttribute("kind", t1.getKind());
		for (Trainer t : trainerrepo.findAll()) {
			if (t.getId() == id) {
				trainerrepo.delete(t);
				break;}}
		Trainer trainer = new Trainer();
		model.addAttribute("trainer", trainer);
//		trainer.setId(id);
//		trainer.setKind(UserKind.Trainer);
//		trainerrepo.save(trainer);
			return "trainer/editprof";
	}
	
//	@RequestMapping("/trainers")
//	public String starts(Model model, Principal principal) {
//		model.addAttribute("trainer", userrepo.findByUsername(principal.getName()));
//		return "trainer/list";
//	}
	

	@PostMapping("/addTrainer")
	public String editprofile(@Valid @ModelAttribute Trainer trainer) {	
		trainerrepo.save(trainer);
		userrepo.save(trainer);
		return "trainer/starttrainer";
		}
	
//	@GetMapping("/trainers")
//	public String starts(Model model, Principal principal) {
//		Iterable<Trainer> u = trainerrepo.findAll();
//			model.addAttribute("Trainer", u);
//		return "trainer/list";
//	}
	
	}
  /**
   * This method will take us to the required form so that we may add new bookings 
   * @param model- This defines the attribute. 
   * @return- This returns thBookinge user to the original page where they can then add a new booking
   * 
   */
//	@RequestMapping("/newBooking")
//	public String newBooking(Model model) {
//		model.addAttribute("hotels", hotrep.findAll().stream().map(x -> x.getName()).collect(Collectors.toList())); //Hw2Application.hotels
//		model.addAttribute("booking", new Booking());
//		return "bookings/form";
//	}
/**
 * This method will let the user add a booking.
 * @param booking-Information is saved into the bookings list her and also placed into the booking. 
 * @param hotelName- This checks that the name of the hotel is identical to that of one in the hotels from the list.
 * @param principal-This returns the list of bookings to the specific user
 * @return-This will take users to the  list of updated bookings that have been made.
 */
	
	/**
	 * this will find the booking that has been made and allow you to delete it
	 * @param id-Ensure that the booking is the same as the id it is labelled under
	 * @return-Returns the user to the updated list of bookings that have been made.
	 */
//	@GetMapping("/deleteBooking")
//	public String deleteBooking(@RequestParam int id) {
//		
//		for (Booking b : trainerrep.findAll()) {
//			if (b.getId() == id) {
//				trainerrep.delete(b);
//				break;
//			}
//		}
//		return "redirect:/b/bookings";
//	}
//}
