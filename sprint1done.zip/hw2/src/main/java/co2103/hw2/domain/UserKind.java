package co2103.hw2.domain;

public enum UserKind {
	Scheduler, Trainer
}
