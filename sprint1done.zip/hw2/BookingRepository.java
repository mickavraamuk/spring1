package co2103.hw2.repository;

import org.springframework.data.repository.CrudRepository;
import java.util.List;
import co2103.hw2.domain.Booking;
import co2103.hw2.domain.Person;


public interface BookingRepository extends CrudRepository<Booking, Integer> {
	
	public List<Booking> findByHotel_Staff(Person staff); //NameContains(String Hotel);
	
	public List<Booking> findByGuests(Person guests);
	
	








}
