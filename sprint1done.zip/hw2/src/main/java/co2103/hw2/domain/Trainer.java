package co2103.hw2.domain;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
/**
 * 
 * @author jnaj1
 *This is the where the trainer's attributes are represented. The username, fullname are all part of the person. 
 */
public class Trainer extends Users {
//    /**
//     * This Id for trainer creates a primary. It is specific to each one. 
//     */
//	@Id
//	//private int id;
//	/**
//	 * This will include a trainer's username.
//	 */
//	private String username;
//	/**
//	 * This variable would be used by trainer's when logging in to the system.
//	 */
//	private String password;
//	/**
//	 * This will include the first and last name.
//	 */
//	private String fullname;
//
//	/**
//	 * this variable is used for different types of users such as managers, guests and staff
//	 */
//	 private UserKind kind;
//	
//	/**
//	 * This will include a trainer's operating location.
//	 */
//	private String operatinglocation;
//	/**
//	 * This will include a trainer's region.
//	 */
//	private String region;
//	/**
//	 * This will include a trainer's skills.
//	 */
//	private String skills;
//	/**
//	 * This will include a trainer's experience.
//	 */
//	private String experience;
//	
	public Trainer(int id,String fullName, String username, String password, String OperatingLocation, String Region, String skills, String experience, UserKind kind) {
		this.id = id;
		this.username = username;
		this.password = password;
		this.fullname = fullName;
		this.kind = kind;
		this.operatinglocation = OperatingLocation;
		this.region = Region;
		this.skills = skills;
		this.experience = experience;
	}
//
//	public UserKind getKind() {
//		return kind;
//	}
//
//	public void setKind(UserKind kind) {
//		this.kind = kind;
//	}
//	public int getid() {
//		return id;
//	}
//	
//	public void setid(int id) {
//		this.id = id;
//	}
//	
//	public String getusername() {
//		return username;
//	}
//
//	public void setusername(String username) {
//		this.username = username;
//	}
//
//	public String getpassword() {
//		return password;
//	}
//
//	public void setpassword(String password) {
//		this.password = password;
//	}
//
//	public String getfullname() {
//		return fullname;
//	}
//
//	public void setfullname(String fullName) {
//		this.fullname = fullName;
//	}
//
//	public String getoperatinglocation() {
//		return operatinglocation;
//	}
//
//	public void setoperatinglocation(String operatingLocation) {
//		operatinglocation = operatingLocation;
//	}
//
//	public String getregion() {
//		return region;
//	}
//
//	public void setregion(String region) {
//		this.region = region;
//	}
//
//	public String getskills() {
//		return skills;
//	}
//
//	public void setskills(String skills) {
//		this.skills = skills;
//	}
//
//	public String getexperience() {
//		return experience;
//	}
//
//	public void setexperience(String experience) {
//		this.experience = experience;
//	}

	public Trainer() {

	}
}