package co2103.hw2.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import co2103.hw2.domain.Person;

public interface PersonRepository extends CrudRepository<Person, String>{
	public Optional<Person> findById(String id);
}