package co2103.hw2.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import co2103.hw2.domain.Trainer;
import co2103.hw2.repository.TrainerRepository;

//package co2103.hw2.controller;
//
//import javax.validation.Valid;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.validation.BindingResult;
//import org.springframework.web.bind.WebDataBinder;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.InitBinder;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//
//import co2103.hw2.Hw2Application;
//import co2103.hw2.domain.Hotel;
//import co2103.hw2.domain.Room;
//import co2103.hw2.repository.HotelRepository;
///**private TrainerRepository trainerrepo;
// * 
// * jnaj1
// *
// */
@Controller

@RequestMapping("/s/")
public class SchedulerController {
	
	@Autowired
	private TrainerRepository trainerrepo;
	
	@GetMapping("/showtrainers")
	public String starts(Model model, Principal principal) {
		Iterable<Trainer> u = trainerrepo.findAll();
			model.addAttribute("Trainer", u);
		return "trainer/list";
	}
	
	
	
	
	
	
//	
//	@Autowired
//	private HotelRepository hotrep;
//
//	
//	
//	@InitBinder
//	protected void initBinder(WebDataBinder binder) {
//		binder.addValidators(new RoomValidator());
//	}
//
//	@GetMapping("/rooms")
//	public String showHotels(@RequestParam String hotel, Model model) {
//		for (Hotel h : hotrep.findAll()) //Hw2Application.hotels) 
//		{
//			if (hotel.equals(h.getName())) {
//				model.addAttribute("rooms", h.getRooms());
//				model.addAttribute("hotel", hotel);
//				break;
//			}
//		}
//		return "rooms/list";
//	}
//
//	@RequestMapping("/newRoom")
//	public String newHotel(@RequestParam String hotel, Model model) {
//		model.addAttribute("room", new Room());
//		model.addAttribute("hotel", hotel);
//		return "rooms/form";
//	}
//
//	@PostMapping("/addRoom")
//	public String newHotel(@RequestParam String hotel, @Valid @ModelAttribute Room room, BindingResult result,
//			Model model) {
//		if (result.hasErrors()) {
//			model.addAttribute("hotel", hotel);
//			return "rooms/form";
//		}
//
//		for (Hotel h : hotrep.findByName(hotel)) 
//				{
//			if (hotel.equals(h.getName())) {
//				h.getRooms().add(room);
//				hotrep.save(h);
//				break;
//			}	
//		}
//		return "redirect:/h/hotels";
//	}
}
